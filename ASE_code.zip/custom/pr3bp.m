
figure
hold on

% set the time span
tspan = [0, 100];
% here we set both error
reltol = 1e-9;
% generate ODE solving options
opts = odeset('RelTol',reltol);


% solve the ODE
% omega is rotational speed of 3 stars
w = (1/3)^(1/4);

% set initial conditions [x,y,px,py]

ic = [1.87; 0; 0; -0.1];
% ic = [1.9691; 0; 0; -1.6944+w*1.9691];
% ic=[1.65518577315705;0;0;-0.269684263822745];
% give position of stars in their static frame
star_pos = [1, -1/2, -1/2; 0, sqrt(3)/2, -sqrt(3)/2];

[t, r] = ode45(@(t,r) odefun(t,r,w, star_pos), tspan, ic, opts);
% extract the solution
x = r(:,1);
y = r(:,2);
px = r(:,3);
py = r(:,4);

% plot the trajectory in x=r cos(theta) and y=r sin(theta)
plot(x,y);
plot(star_pos(1,:),star_pos(2,:),'ro'); % position of stars
plot(x(1), y(1), 'go'); % initial position
plot(x(end), y(end), 'bo'); % final position
xlabel('x''');
ylabel('y''');
%title(sprintf('%0.3f',pi));
grid on
axis equal 
hold off

% check how well the energy is conserved and see if the relative error is sufficiently small
% H = Hamiltonian(x,y,xd,yd,w, star_pos);
% initial
% H0 = Hamiltonian(x(1),y(1),xd(1),yd(1),w, star_pos);
% figure
% plot(t,H-H0);
% xlabel('t');
% ylabel('\Delta H');
