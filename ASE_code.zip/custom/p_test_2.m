% Example 3.6
% Note: it takes a few minutes to complete a run
clear all
close all

figure
hold on

% the number of p2s we hope to explore
np2 = 25;
% the number of times for each orbit
nppts = 800;

% set the parameters 
w = (1/3)^(1/4);
star_pos = [1, -1/2, -1/2; 0, sqrt(3)/2, -sqrt(3)/2];
xi = star_pos(1, :); % first row
yi = star_pos(2, :); % second row


% set the time span
tspan = [0, 100];
% here we set both error
reltol = 1e-9;
abstol = 1e-9;

% generate ODE solving options
opts = odeset('RelTol',reltol,'AbsTol',abstol,'Events', @DPEventsFcn);

% initial conditions 
x0 = 1.73;
y0 = 0;
px0 = 0;
py0 = -1.6842+w*x0;

% define sum
sum_r = 0;
for n=1:3
    sum_r = sum_r + 1./sqrt((x0-xi(n)).^2+(y0-yi(n)).^2);
end
    
% The fixed value of Hamiltonian we are looking at
Hfixed = Hamiltonian(x0, y0, px0, py0, w, star_pos);
% py_min = w*x0 - (w^2*x0^2 - 2*y0*w*px0 - px0^2 + 2*Hfixed + 2*sum_r)^(1/2);
% py_max = w*x0 + (w^2*x0^2 - 2*y0*w*px0 - px0^2 + 2*Hfixed + 2*sum_r)^(1/2);

pylist = linspace(py0-0.2,py0+0.2, np2);%[py0]; %linspace(py0, py0+10, 10);
x0list = zeros(1,np2);
for i=1:numel(pylist)
    syms x0
    sum_r = 0;
    for n=1:3
        sum_r = sum_r + 1./sqrt((x0-xi(n)).^2+(y0-yi(n)).^2);
    end
    py0 = pylist(i);
    x0list(i) = double(vpasolve(1/2*(px0.^2 + py0.^2) + w*y0.*px0 - w*x0.*py0 - sum_r==Hfixed,x0, 1.9));
end

% solve the ODE nppts times
for i=1:numel(pylist)
    
    % initial py 
    py0 = pylist(i);
    x0 = x0list(i);
    % define the sum
%     syms x0
%     sum_r = 0;
%     for n=1:3
%         sum_r = sum_r + 1./sqrt((x0-xi(n)).^2+(y0-yi(n)).^2);
%     end
%     x0 = double(vpasolve(1/2*(px0.^2 + py0.^2) + w*y0.*px0 - w*x0.*py0 - sum_r==Hfixed,x0, 1.73));
    % px0 = solve(1/2*(px0.^2 + py0.^2) + w*y0.*px0 - w*x0.*py0 - sum_r==Hfixed);%(w^2*y0^2 + 2*x0*w*py0 - py0^2 + 2*Hfixed + 2*sum_r)^(1/2) - w*y0;
     % catch for complex values
%     if abs(imag(px0))>1e-10
%         disp('complex')
%         continue
%     end
    
    %w*x0 - (w^2*x0^2 - 2*y0*w*px0 - px0^2 + 2*Hfixed + 2*sum_r)^(1/2);
    
    % set a range of initial conditions [x1,x2,p1,p2]
    ic=[x0;y0;px0;py0];
    
     % is dx/dt > 0? yes, continue; no, switch to another root
%     dydt = odefun(0, ic, w, star_pos);
    
%     if (dydt(2) >= 0)
%         px0 = -(w*y0^2 + 2*x0*w*py0 - py0^2 + 2*Hfixed + 2*sum_r)^(1/2) - w*y0;
%         ic=[x0;y0;px0;py0];
%     end
    
    % add IC to plot
    pxplot(1) = px0;
    xplot(1) = x0;

    for j = 1:nppts
        [t,y, te, ye, ie] = ode45(@(t,y) odefun(t, y, w, star_pos), tspan, ic, opts);

        id = 1; % extract the subsequent timestep

        % extract the solution
        x1 = ye(id,1);
        x2 = ye(id,2);
        p1 = ye(id,3);
        p2 = ye(id,4);

        xplot(j+1) = x1;
        pxplot(j+1) = p1;

        ic = [x1;x2;p1;p2]; 
    end

    scatter(xplot,pxplot,'.');

end
xlabel('x''');
ylabel('px''');


