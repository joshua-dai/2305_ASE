function hamiltonian = hamil(xp_dot,yp_dot, xp,yp)
    syms omega % this is just some constant
    r1 = sqrt((xp-1)^2+yp^2);
    r2 = sqrt((xp+1/2)^2+(yp-sqrt(3)/2)^2);
    r3 = sqrt((xp+1/2)^2+(yp+sqrt(3)/2)^2);
    
    % substitute xp_dot, yp_dot into the momentum transform
    p_xp = xp_dot-omega*yp;
    p_yp = yp_dot+omega*xp;
    
    hamiltonian = 1/2*(p_xp^2+p_yp^2)+omega*yp*p_xp-omega*xp*p_yp-(1/r1+1/r2+1/r3);
end
% function hamiltonian = hamil(p_xp,p_yp, xp,yp)
%     syms omega % this is just some constant
%     r1 = sqrt((xp-1)^2+yp^2);
%     r2 = sqrt((xp+1/2)^2+(yp-sqrt(3)/2)^2);
%     r3 = sqrt((xp+1/2)^2+(yp+sqrt(3)/2)^2);
%     
%     % substitute xp_dot, yp_dot into the momentum transform    
%     hamiltonian = 1/2*(p_xp^2+p_yp^2)+omega*yp*p_xp-omega*xp*p_yp-(1/r1+1/r2+1/r3);
% end