syms p_xp p_yp xp yp
deyp = diff(hamil(p_xp,p_yp,xp,yp), yp);
dexp = diff(hamil(p_xp,p_yp,xp,yp), xp);
dep_yp = diff(hamil(p_xp,p_yp,xp,yp), p_yp);
dep_xp = diff(hamil(p_xp,p_yp,xp,yp), p_xp);

% syms xp_dot yp_dot xp yp
% deyp = diff(hamil(xp_dot,yp_dot,xp,yp), yp)
% dexp = diff(hamil(xp_dot,yp_dot,xp,yp), xp)
% deyp_dot = diff(hamil(xp_dot,yp_dot,xp,yp), yp_dot)
% dexp_dot = diff(hamil(xp_dot,yp_dot,xp,yp), xp_dot)

