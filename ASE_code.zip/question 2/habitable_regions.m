
% create a grid from x in [-3,3], y in [-3,3]
square_ran = 2;
x = linspace(-square_ran,square_ran,300);
y = linspace(-square_ran,square_ran,300);
[X,Y] = meshgrid(x,y);

% compute the potential V
V = u(X,Y);
figure;
    
hold on
% plot V, linspace(-3,-1,100) means we only show values in [-3, -1] with
% 100 contour steps
contourf(x,y,V, linspace(-4,-1,100));

% plot the ranges
star_pos = [1, -1/2, -1/2;0, sqrt(3)/2, -sqrt(3)/2];

for i=1:3
    circle(star_pos(1,i),star_pos(2,i), 0.6, 'r', 1.5); % LB
%     circle(star_pos(1,i),star_pos(2,i), 1.6, 'b'); % outer region LB
    circle(star_pos(1,i),star_pos(2,i), 1, 'g', 1.5); % UB
end
% plot(star_pos, star_pos, 'ro', 'MarkerSize', 1.6); % outer LB
% plot(star_pos, star_pos, 'ro', 'MarkerSize', 2.0); % outer UB

% old distance code
% dist = sqrt((X-star_pos(1,1)).^2 + (Y-star_pos(2,1)).^2);
% % Find points with 0.1 tolerance of 398.453 away from point (ix,iy)
% tolerance = 0.01;
% farAwayIndexes = abs(dist - 0.6)<tolerance;
% plot(X(farAwayIndexes), Y(farAwayIndexes), '--r')
%plot(star_pos(1,:),star_pos(2,:),'ro', 'DisplayName', 'Stars'); % position of stars

axis equal 
xlabel('$x\prime$', 'interpreter', 'latex')
ylabel('$y\prime$', 'interpreter', 'latex')
%surf(x, y, V)
%zlim([-5 -1])
hold off
% Find Lagrange point from gradV=0, given some initial guess

% x = fsolve(@vfun,[0.03, 1.7])
